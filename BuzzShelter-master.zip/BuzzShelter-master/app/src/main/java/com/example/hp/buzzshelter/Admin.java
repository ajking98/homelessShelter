package com.example.hp.buzzshelter;

/**
 * Created by HP on 3/20/2018.
 */

public class Admin extends User {

    public Admin(String name, String loginEmail, String password) {
        super(name, loginEmail, password);
    }

}
