package com.example.hp.buzzshelter;

/**
 * Created by HP on 3/22/2018.
 */

public enum Gender {
    MALE, FEMALE, OTHER;
}
