# CS_2340_TEAM66_ICETRAYDAGANG
The project for GaTech CS 2340 Objects and Design Spring 2018. 
This semester's goal is to make an android application that helps the homeless of Atlanta find shelters and resources.

Matthew Jinks: mjinks3@gatech.edu
Austin Neely: aneely7@gatech.edu
Bianca Dankwa: bdankwa6@gatech.edu
Anton Turner: aturner61@gatech.edu 
Yizra Ghebre: yizra.g@gmail.com 
Ahmed Gedi: ahmedgedi@gatech.edu 
